export class Menu {
    public men_id:number;
    public men_item:string;
    public men_price:number;
    public men_calories:number;
    public men_speciality:string;
    constructor(){
        
    }
}
